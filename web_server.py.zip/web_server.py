import socket

addr = ("", 8080)  # all interfaces, port 8080
# if socket.has_dualstack_ipv6():
#     s = socket.create_server(addr, family=socket.AF_INET6, dualstack_ipv6=True)
# else:
#     s = socket.create_server(addr)


server = socket.create_server(addr, family = socket.AF_INET6)
# Move to listen state
server.listen()

# Serve to connection requests
print("Server starts to accept connections from clients...")
while(True):
    serveOn = server.accept()
    print("Connection accepted...client details:",serveOn[1])
    msg = "<h1>hi</h1>"
    clientMsg=serveOn[0].recv(1024)
    print("Message received:%s"%clientMsg.decode())
    print("Sending greetings to client")
    serveOn[0].send(msg.encode())
    serveOn[0].close()
    print("Connection to client closed")